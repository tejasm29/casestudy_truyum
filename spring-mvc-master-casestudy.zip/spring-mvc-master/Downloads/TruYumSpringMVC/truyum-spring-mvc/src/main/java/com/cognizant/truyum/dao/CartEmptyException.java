package com.cognizant.truyum.dao;
import java.lang.Exception;
@SuppressWarnings("serial")


public class CartEmptyException extends Exception{
	public CartEmptyException(){
		
	}
}
